python FL_server.py
python FL_client.py
python FullNode.py